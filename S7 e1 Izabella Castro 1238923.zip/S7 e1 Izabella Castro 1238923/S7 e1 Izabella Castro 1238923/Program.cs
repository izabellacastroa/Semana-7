﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Ingresar un entero positivo ");
        int numero = int.Parse(Console.ReadLine());

        int suma = 0;
        for (int i = 2; i <= numero; i += 2)
        {
            suma += i;
        }

        Console.WriteLine("La suma de todos los números pares desde 2 hasta {0} son: {1}", numero, suma);
    }
}

