﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Ingresar clase tarjeta (1, 2, 3 u otro):");
        int claseTarjeta = int.Parse(Console.ReadLine());
        Console.WriteLine("Ingresar límite crediticio actual:");
        decimal limiteActual = decimal.Parse(Console.ReadLine());
        decimal aumentoPorcentaje = 0;
        if (claseTarjeta == 1)
        {
            aumentoPorcentaje = 0.25m;
        }
        else if (claseTarjeta == 2)
        {
            aumentoPorcentaje = 0.35m;
        }
        else if (claseTarjeta == 3)
        {
            aumentoPorcentaje = 0.40m;
        }
        else
        {
            aumentoPorcentaje = 0.50m;
        }
        decimal aumentoCredito = limiteActual * aumentoPorcentaje;
        decimal nuevoLimite = limiteActual + aumentoCredito;
        Console.WriteLine("Límite crediticio actual: $" + nuevoLimite);
    }
}

