﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Ingresar un número: ");
        int numero = int.Parse(Console.ReadLine());

        Console.WriteLine("Serie de Fibonacci:");
        FibonacciSeries(numero);
        Console.ReadKey();
    }

    static void FibonacciSeries(int n)
    {
        int a = 0;
        int b = 1;

        Console.Write(a + " ");
        int suma = 0;
        while (suma < n)
        {
            suma = a + b;

            //if (suma > n)
               // break;

            Console.Write(suma + " ");

            a = b;
            b = suma;
        }
    }
}