﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Random random = new Random();
        int numeroRandom = random.Next(1, 101);

        Console.WriteLine("Adivina el número entre 1 y 100");

        int intento = 0;
        bool adivinarcorrecto = false;

        while (!adivinarcorrecto)
        {
            Console.Write("Ingresar respuesta: ");
            int adivinar = int.Parse(Console.ReadLine());
            intento++;

            if (adivinar == numeroRandom)
            {
                adivinarcorrecto = true;
                Console.WriteLine($"Bien hecho, adivinaste el número {numeroRandom} correctamente.");
                Console.WriteLine($"Te tomó {intento} intentos.");
            }
            else if (adivinar < numeroRandom)
            {
                Console.WriteLine("Número muy pequeño, intenta de nuevo.");
            }
            else
            {
                Console.WriteLine("Número muy alto, Intenta de nuevo.");
            }
        }
    }
}

